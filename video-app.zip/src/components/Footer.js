import React from 'react';
import styled from 'styled-components';

const FooterContainer = styled.footer`
  background-color: #282c34;
  display: flex;
  justify-content: space-around;
  padding: 10px;
`;

const TabButton = styled.button`
  background-color: ${(props) => (props.active ? '#61dafb' : 'transparent')};
  border: none;
  color: white;
  cursor: pointer;
  font-size: 16px;
  padding: 10px;
`;

function Footer({ activeTab, setActiveTab }) {
  return (
    <FooterContainer>
      <TabButton
        active={activeTab === 'home'}
        onClick={() => setActiveTab('home')}
      >
        Home
      </TabButton>
      <TabButton
        active={activeTab === 'user'}
        onClick={() => setActiveTab('user')}
      >
        User
      </TabButton>
      <TabButton
        active={activeTab === 'playlists'}
        onClick={() => setActiveTab('playlists')}
      >
        Playlists
      </TabButton>
      <TabButton
        active={activeTab === 'favorites'}
        onClick={() => setActiveTab('favorites')}
      >
        Favorites
      </TabButton>
      <TabButton
        active={activeTab === 'local'}
        onClick={() => setActiveTab('local')}
      >
        Local Music
      </TabButton>
    </FooterContainer>
  );
}

export default Footer;
