import React from 'react';
import styled from 'styled-components';
import ReactPlayer from 'react-player';

const HeaderContainer = styled.header`
  background-color: #282c34;
  color: white;
  padding: 10px;
`;

const VideoPlayerWrapper = styled.div`
  max-width: 640px;
  margin: 0 auto;
`;

function Header() {
  return (
    <HeaderContainer>
      <h1>Video App</h1>
      <VideoPlayerWrapper>
        <ReactPlayer
          url="https://www.youtube.com/watch?v=dQw4w9WgXcQ"
          width="100%"
          height="360px"
          controls
        />
      </VideoPlayerWrapper>
    </HeaderContainer>
  );
}

export default Header;
