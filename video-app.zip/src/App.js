import React, { useState } from 'react';
import styled from 'styled-components';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/Home';
import User from './components/User';
import Playlists from './components/Playlists';
import Favorites from './components/Favorites';
import LocalMusic from './components/LocalMusic';

const AppContainer = styled.div`
  display: flex;
  flex-direction: column;
  height: 100vh;
`;

const MainContent = styled.main`
  flex: 1;
  overflow-y: auto;
`;

function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <Home />;
      case 'user':
        return <User />;
      case 'playlists':
        return <Playlists />;
      case 'favorites':
        return <Favorites />;
      case 'local':
        return <LocalMusic />;
      default:
        return <Home />;
    }
  };

  return (
    <AppContainer>
      <Header />
      <MainContent>{renderContent()}</MainContent>
      <Footer activeTab={activeTab} setActiveTab={setActiveTab} />
    </AppContainer>
  );
}

export default App;
